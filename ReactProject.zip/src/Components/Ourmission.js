import React from 'react';

const Ourmission = () => {
    return (


        <div>
        <h1>HI i am Abhinav trehan</h1>
          <h2>Founder and Chairperson</h2>
          <p>I am very happy to announce the inauguration of the Kunjbihari Goyal's
               online academy GOLD. With the launch of Online website, GOLD Academy 
               enters the realm of completely different and innovative approach of
                providing knowledge. The future of learning lies in online learning,
                 which is quick to access and very convenient for the aspiring learners. 
                 With a few steps, anyone can easily access lots of learning resources today using technology.
                  GOLD Online Academy is very excited to leverage on these 
                  substantial benefits of technology and envisions providing online 
                  learning solutions to reach out to those who face many learning barriers.
                   The barriers faced are various, including shortage of schools and colleges,
                    lack of teachers, dearth of textbooks in the vicinity of where the students stay.
                     To overcome these barriers, GOLD Academy has started this new initiativ
                     e so as to make the learning smooth and not something which is difficult t
                     o be undertaken,I thank everyone from my team who contributed towards the launch of this academy, and
               wish my entire team good wishes to make this opportunity reach milestones and do
                wonders and benefit the learning community. To my users, I hope that this academy
                would contribute towards your understanding on various areas and build you as a
                   knowledgeable and well-informed individual.



                As an initial step, we made this learning portal of GOLD
                accessible to the students of Ghanshyamdas Saraf College of Commerce(GSC)
                 and Ladhidevi Ramdhar Maheshwari Night College of Commerce(LRMC).
                In the coming days, the academy would have a look at its performance 
                and understand from its students on the different ways in which the offerings can be enhanced.
               The academy then would set out on the next milestones for widening the access of the learning platform. 
                 The academy seeks blessings and support from all its well-wishers to become a resourceful and beneficial hub of learning.

                 -   Mr. Ashok Saraf</p>

                </div>
)

}
export default Ourmission;